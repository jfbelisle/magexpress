/* global vc, i18nLocale */
(function ( $ ) {
	'use strict';
	vc.TemplateWindowUIPanelBackendEditor
})( window.jQuery );